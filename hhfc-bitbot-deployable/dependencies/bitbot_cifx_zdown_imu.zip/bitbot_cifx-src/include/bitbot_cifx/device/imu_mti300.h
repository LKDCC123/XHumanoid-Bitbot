#pragma once

#include "bitbot_cifx/device/cifx_imu.hpp"
#include <Eigen/Core>
#include <Eigen/Geometry>

namespace bitbot
{
  class ImuMti300 final: public CifxImu
  {
  public:
    ImuMti300(const pugi::xml_node& imu_node);

    void InitSDO(){}

    void Input(void* bus_data) final override;
    
    void* Output() final override;
    
  private:
    virtual void UpdateRuntimeData() final override;

    std::array<uint8_t, 2> bus_send_data_{0};
    std::array<uint8_t, 36> bus_receive_data_{0};
  };  
}
